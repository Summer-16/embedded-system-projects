/**
  ******************************************************************************
  * File Name          : main.c
  * Description        : Main program body
  ******************************************************************************
  ** This notice applies to any and all portions of this file
  * that are not between comment pairs USER CODE BEGIN and
  * USER CODE END. Other portions of this file, whether 
  * inserted by the user or by software development tools
  * are owned by their respective copyright owners.
  *
  * COPYRIGHT(c) 2017 STMicroelectronics
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32f0xx_hal.h"

/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private variables ---------------------------------------------------------*/
UART_HandleTypeDef huart1;
UART_HandleTypeDef huart3;

/* USER CODE BEGIN PV */
/* Private variables ---------------------------------------------------------*/
unsigned char ch;
int a=0,b=0,flag=0;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART1_UART_Init(void);
static void MX_USART3_UART_Init(void);

/* USER CODE BEGIN PFP */
/* Private function prototypes -----------------------------------------------*/

/* USER CODE END PFP */

/* USER CODE BEGIN 0 */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
  /* Prevent unused argument(s) compilation warning */
  UNUSED(huart);
if(huart->Instance==USART3)
{
HAL_UART_Receive_IT(&huart3,&ch,1);
HAL_UART_Transmit(&huart1,&ch,1,10);
flag=1;

}
  /* NOTE : This function should not be modified, when the callback is needed,
            the HAL_UART_RxCpltCallback can be implemented in the user file.
   */
}


void heartattack()
{
	while(1)
{
  a=HAL_GPIO_ReadPin(GPIOC,GPIO_PIN_0); //SENSOR
  HAL_GPIO_WritePin(GPIOC,GPIO_PIN_1,1); //MOTOR START
  if(a==1)
  {
		HAL_GPIO_WritePin(GPIOB,GPIO_PIN_4,1); // LED
    b++;
    HAL_Delay(100);
		HAL_GPIO_WritePin(GPIOB,GPIO_PIN_4,0); //LED
    }
    if(b==2)
    {
      HAL_GPIO_WritePin(GPIOC,GPIO_PIN_1,0); //MOTOR STOP
      b=0;
      break;
      }
  }
}

void bp()
{
	while(1)
{
  a=HAL_GPIO_ReadPin(GPIOC,GPIO_PIN_2);  //SENSOR
  HAL_GPIO_WritePin(GPIOC,GPIO_PIN_3,1);  //MOTOR START
  if(a==1)
  {
		HAL_GPIO_WritePin(GPIOB,GPIO_PIN_4,1); // LED
    b++;
    HAL_Delay(100);
		HAL_GPIO_WritePin(GPIOB,GPIO_PIN_4,0); //LED
    }
    if(b==2)
    {
      HAL_GPIO_WritePin(GPIOC,GPIO_PIN_3,0); //MOTOR STOP
      b=0;
      break;
      }
  }
}

void allergy()
{
	while(1)
{
  a=HAL_GPIO_ReadPin(GPIOC,GPIO_PIN_6);  //SENSOR
  HAL_GPIO_WritePin(GPIOC,GPIO_PIN_7,1);  //MOTOR START
  if(a==1)
  {
		HAL_GPIO_WritePin(GPIOB,GPIO_PIN_4,1); // LED
    b++;
    HAL_Delay(100);
		HAL_GPIO_WritePin(GPIOB,GPIO_PIN_4,0); //LED
    }
    if(b==2)
    {
      HAL_GPIO_WritePin(GPIOC,GPIO_PIN_7,0);  //MOTOR STOP
      b=0;
      break;
      }
  }
}

void pain()
{
	while(1)
{
  a=HAL_GPIO_ReadPin(GPIOC,GPIO_PIN_8);  //SENSOR
  HAL_GPIO_WritePin(GPIOC,GPIO_PIN_9,1);  //MOTOR START
  if(a==1)
  {
		HAL_GPIO_WritePin(GPIOB,GPIO_PIN_4,1); // LED
    b++;
    HAL_Delay(100);
		HAL_GPIO_WritePin(GPIOB,GPIO_PIN_4,0); //LED
    }
    if(b==2)
    {
      HAL_GPIO_WritePin(GPIOC,GPIO_PIN_9,0);   //MOTOR STOP
      b=0;
      break;
      }
  }
}

void fever()
{
	while(1)
{
  a=HAL_GPIO_ReadPin(GPIOA,GPIO_PIN_4);  //SENSOR
  HAL_GPIO_WritePin(GPIOA,GPIO_PIN_5,1);  //MOTOR START
  if(a==1)
  {
		HAL_GPIO_WritePin(GPIOB,GPIO_PIN_4,1); // LED
    b++;
    HAL_Delay(100);
		HAL_GPIO_WritePin(GPIOB,GPIO_PIN_4,0); //LED
    }
    if(b==2)
    {
      HAL_GPIO_WritePin(GPIOA,GPIO_PIN_5,0);  //MOTOR STOP
      b=0;
      break;
      }
  }
}

void cold()
{
	while(1)
{
  a=HAL_GPIO_ReadPin(GPIOA,GPIO_PIN_6);  //SENSOR
  HAL_GPIO_WritePin(GPIOA,GPIO_PIN_7,1);  //MOTOR START
  if(a==1)
  {
		HAL_GPIO_WritePin(GPIOB,GPIO_PIN_4,1); // LED
    b++;
    HAL_Delay(100);
		HAL_GPIO_WritePin(GPIOB,GPIO_PIN_4,0); //LED
    }
    if(b==2)
    {
      HAL_GPIO_WritePin(GPIOA,GPIO_PIN_7,0);  //MOTOR STOP
      b=0;
      break;
      }
  }
}

void rti()
{
	while(1)
{
  a=HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_5);  //SENSOR
  HAL_GPIO_WritePin(GPIOC,GPIO_PIN_13,1);  //MOTOR START
  if(a==1)
  {
		HAL_GPIO_WritePin(GPIOB,GPIO_PIN_4,1); // LED
    b++;
    HAL_Delay(100);
		HAL_GPIO_WritePin(GPIOB,GPIO_PIN_4,0); //LED
    }
    if(b==2)
    {
      HAL_GPIO_WritePin(GPIOC,GPIO_PIN_13,0);  //MOTOR STOP
      b=0;
      break;
      }
  }
}

void diarrhea()
{
	while(1)
{
  a=HAL_GPIO_ReadPin(GPIOA,GPIO_PIN_11);  //SENSOR
  HAL_GPIO_WritePin(GPIOA,GPIO_PIN_12,1);  //MOTOR START
  if(a==1)
  {
		HAL_GPIO_WritePin(GPIOB,GPIO_PIN_4,1); // LED
    b++;
    HAL_Delay(100);
		HAL_GPIO_WritePin(GPIOB,GPIO_PIN_4,0); //LED
    }
    if(b==2)
    {
      HAL_GPIO_WritePin(GPIOA,GPIO_PIN_12,0);  //MOTOR STOP
      b=0;
      break;
      }
  }
}

void sugar()
{
	while(1)
{
  a=HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_3);  //SENSOR
  HAL_GPIO_WritePin(GPIOB,GPIO_PIN_6,1);  //MOTOR START
  if(a==1) 
  {
		HAL_GPIO_WritePin(GPIOB,GPIO_PIN_4,1); // LED
    b++;
    HAL_Delay(100);
		HAL_GPIO_WritePin(GPIOB,GPIO_PIN_4,0); //LED
    }
    if(b==2)
    {
      HAL_GPIO_WritePin(GPIOB,GPIO_PIN_6,0);  //MOTOR STOP
      break;
      }
  }
}
/* USER CODE END 0 */

int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration----------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART1_UART_Init();
  MX_USART3_UART_Init();

  /* USER CODE BEGIN 2 */

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
  /* USER CODE END WHILE */

  /* USER CODE BEGIN 3 */
HAL_UART_Receive_IT(&huart3,&ch,1);
		
		
//HAL_GPIO_WritePin(GPIOC,motorheart_Pin,1);

//heartattack();
//HAL_Delay(2000);
		
if(flag==1)
{
if(ch=='A')
{
	heartattack();
}	


if(ch==1)
{
	bp();
}	

if(ch==2)
{
	allergy();
}	

if(ch==3)
{
	pain();
}	

if(ch==4)
{
	fever();
}	

if(ch==5)
{
	cold();
}	

if(ch==6)
{
	rti();
}	

if(ch==7)
{
	diarrhea();
}	

if(ch==8)
{
	sugar();
}	


flag=0;
ch='n';

  }

	
	}
  /* USER CODE END 3 */

}

/** System Clock Configuration
*/
void SystemClock_Config(void)
{

  RCC_OscInitTypeDef RCC_OscInitStruct;
  RCC_ClkInitTypeDef RCC_ClkInitStruct;
  RCC_PeriphCLKInitTypeDef PeriphClkInit;

    /**Initializes the CPU, AHB and APB busses clocks 
    */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL3;
  RCC_OscInitStruct.PLL.PREDIV = RCC_PREDIV_DIV1;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Initializes the CPU, AHB and APB busses clocks 
    */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USART1;
  PeriphClkInit.Usart1ClockSelection = RCC_USART1CLKSOURCE_PCLK1;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Configure the Systick interrupt time 
    */
  HAL_SYSTICK_Config(HAL_RCC_GetHCLKFreq()/1000);

    /**Configure the Systick 
    */
  HAL_SYSTICK_CLKSourceConfig(SYSTICK_CLKSOURCE_HCLK);

  /* SysTick_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(SysTick_IRQn, 0, 0);
}

/* USART1 init function */
static void MX_USART1_UART_Init(void)
{

  huart1.Instance = USART1;
  huart1.Init.BaudRate = 9600;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  huart1.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart1.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

}

/* USART3 init function */
static void MX_USART3_UART_Init(void)
{

  huart3.Instance = USART3;
  huart3.Init.BaudRate = 9600;
  huart3.Init.WordLength = UART_WORDLENGTH_8B;
  huart3.Init.StopBits = UART_STOPBITS_1;
  huart3.Init.Parity = UART_PARITY_NONE;
  huart3.Init.Mode = UART_MODE_TX_RX;
  huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart3.Init.OverSampling = UART_OVERSAMPLING_16;
  huart3.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart3.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart3) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

}

/** Configure pins as 
        * Analog 
        * Input 
        * Output
        * EVENT_OUT
        * EXTI
*/
static void MX_GPIO_Init(void)
{

  GPIO_InitTypeDef GPIO_InitStruct;

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOF_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13|GPIO_PIN_1|GPIO_PIN_3|GPIO_PIN_7 
                          |GPIO_PIN_9, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5|GPIO_PIN_7|GPIO_PIN_12, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4|GPIO_PIN_6, GPIO_PIN_RESET);

  /*Configure GPIO pins : PC13 PC1 PC3 PC7 
                           PC9 */
  GPIO_InitStruct.Pin = GPIO_PIN_13|GPIO_PIN_1|GPIO_PIN_3|GPIO_PIN_7 
                          |GPIO_PIN_9;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : PC0 PC2 PC6 PC8 */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_2|GPIO_PIN_6|GPIO_PIN_8;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : PA4 PA6 PA11 */
  GPIO_InitStruct.Pin = GPIO_PIN_4|GPIO_PIN_6|GPIO_PIN_11;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : PA5 PA7 PA12 */
  GPIO_InitStruct.Pin = GPIO_PIN_5|GPIO_PIN_7|GPIO_PIN_12;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : PB3 PB5 */
  GPIO_InitStruct.Pin = GPIO_PIN_3|GPIO_PIN_5;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : PB4 PB6 */
  GPIO_InitStruct.Pin = GPIO_PIN_4|GPIO_PIN_6;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @param  None
  * @retval None
  */
void _Error_Handler(char * file, int line)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  while(1) 
  {
  }
  /* USER CODE END Error_Handler_Debug */ 
}

#ifdef USE_FULL_ASSERT

/**
   * @brief Reports the name of the source file and the source line number
   * where the assert_param error has occurred.
   * @param file: pointer to the source file name
   * @param line: assert_param error line source number
   * @retval None
   */
void assert_failed(uint8_t* file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
    ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */

}

#endif

/**
  * @}
  */ 

/**
  * @}
*/ 

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
